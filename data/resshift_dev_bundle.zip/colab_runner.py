"""ResShift-only Colab runner. No data generation or baseline inference."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import platform
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
RUN = ROOT / 'run_artifacts'
OFFICIAL_COMMIT = 'bb03b7d21614cace01787e097c8a6ab6b945227d'


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def verify():
    provenance = json.loads((ROOT / 'bundle_manifest.json').read_text())
    for name, digest in provenance['sha256'].items():
        p = ROOT / name
        if not p.is_file() or sha256(p) != digest:
            raise RuntimeError(f'Input/source checksum mismatch: {name}. Re-upload the original archive.')
    print(f"Verified {len(provenance['sha256'])} immutable files; 64 HR + 256 LR; baseline commit {provenance['baseline_commit'][:7]}", flush=True)
    return provenance


def setup():
    verify()
    import torch
    if not torch.cuda.is_available():
        raise RuntimeError('Select a Colab GPU runtime before setup. CPU/MPS runs are disabled for this notebook.')
    official = ROOT / 'third_party' / 'ResShift'
    official.parent.mkdir(parents=True, exist_ok=True)
    if not (official / '.git').exists():
        subprocess.run(['git', 'init', str(official)], check=True)
        subprocess.run(['git', '-C', str(official), 'remote', 'add', 'origin', 'https://github.com/zsyOAOA/ResShift.git'], check=True)
    subprocess.run(['git', '-C', str(official), 'fetch', '--depth', '1', 'origin', OFFICIAL_COMMIT], check=True)
    subprocess.run(['git', '-C', str(official), 'checkout', '--detach', OFFICIAL_COMMIT], check=True)
    assert subprocess.check_output(['git', '-C', str(official), 'rev-parse', 'HEAD'], text=True).strip() == OFFICIAL_COMMIT
    sys.path.insert(0, str(ROOT / 'code' / 'datasets'))
    from download_data import download_file, WEIGHTS
    for name in ['resshift_realsrx4_s4_v3.pth', 'autoencoder_vq_f4.pth']:
        download_file(WEIGHTS[name], ROOT / 'models' / name)
    print('Only ResShift and its autoencoder weights are ready. Baseline weights are not downloaded.', flush=True)


def run():
    provenance = verify()
    os.environ['MPLBACKEND'] = 'Agg'
    os.environ['MPLCONFIGDIR'] = str(ROOT / 'cache' / 'matplotlib')
    for sub in ['datasets', 'models', 'evaluation']:
        sys.path.insert(0, str(ROOT / 'code' / sub))
    import torch
    import numpy as np
    import pandas as pd
    import lpips
    import upscale
    import evaluate
    import make_figures
    if not torch.cuda.is_available():
        raise RuntimeError('GPU required. Select a GPU runtime in Colab; no CPU fallback is allowed.')
    device = torch.device('cuda')
    official = ROOT / 'third_party' / 'ResShift'
    assert subprocess.check_output(['git', '-C', str(official), 'rev-parse', 'HEAD'], text=True).strip() == OFFICIAL_COMMIT
    assert not subprocess.check_output(['git', '-C', str(official), 'status', '--porcelain'], text=True).strip(), 'Official source was modified.'
    manifest = pd.read_csv(ROOT / 'data/processed/manifest.csv')
    images = manifest[manifest['split'] == 'dev']
    assert len(images) == 64 and images.image_id.is_unique
    ids = images.image_id.tolist()
    baseline = pd.read_csv(ROOT / 'baseline/metrics_dev.csv', dtype={'jpeg': str})
    base_methods = {'bicubic', 'realesrnet', 'realesrgan'}
    assert set(baseline.method) == base_methods and len(baseline) == 768
    for _, group in baseline.groupby(['method', 'jpeg']):
        assert set(group.image_id) == set(ids)
    RUN.mkdir(parents=True, exist_ok=True)
    (RUN / 'complete.json').unlink(missing_ok=True)
    torch.hub.set_dir(str(ROOT / 'cache' / 'torch'))
    upscale.OUTPUTS_DIR = RUN / 'outputs'
    evaluate.OUTPUTS_DIR = upscale.OUTPUTS_DIR
    evaluate.METHODS = ['resshift']
    print('Inference: ResShift only, dev only, 64 images x 4 JPEG settings.', flush=True)
    timing = upscale.run_method('resshift', ids, 'dev', device)
    report = {
        'split': 'dev', 'method': 'resshift', 'source_commit': provenance['diffusion_commit'],
        'official_commit': OFFICIAL_COMMIT, 'baseline_commit': provenance['baseline_commit'],
        'device': torch.cuda.get_device_name(0), 'torch': torch.__version__,
        'precision': 'float32 model parameters; CUDA autocast float16 enabled',
        'amp': True, 'seed_policy': 'crc32(image_id.encode(utf-8)) & 0x7fffffff; same seed across JPEG levels',
        'diffusion_steps': 4, 'scale': 4, 'input_size': 128, 'output_size': 512, 'batch_size': 1,
        'warmup_runs': upscale.WARMUP_IMAGES,
        'weights_sha256': {name: sha256(ROOT / 'models' / name) for name in ['resshift_realsrx4_s4_v3.pth', 'autoencoder_vq_f4.pth']},
        'timing': timing,
        'timing_note': 'ResShift measured on this GPU; baseline timings came from another run and are not directly comparable.'
    }
    (RUN / 'upscale_report_resshift_dev.json').write_text(json.dumps(report, indent=2))
    # A metric network is evaluated here; none of the three baseline SR models is loaded.
    model = lpips.LPIPS(net='alex', verbose=False).eval().to(device)
    evaluate.check_metrics(evaluate.load_image(evaluate.HR_DIR / f'{ids[0]}.png'), model, device)
    metrics = evaluate.evaluate_split('dev', manifest, model, device)
    assert len(metrics) == 256 and set(metrics.method) == {'resshift'}
    assert not metrics.duplicated(['image_id', 'method', 'jpeg']).any()
    assert np.isfinite(metrics[evaluate.METRICS].to_numpy()).all()
    summary = evaluate.summarize(metrics, 42)
    metrics.to_csv(RUN / 'metrics_resshift_dev.csv', index=False)
    summary.to_csv(RUN / 'summary_resshift_dev.csv', index=False)
    combined = pd.concat([baseline, metrics], ignore_index=True)
    combined_dir = RUN / 'combined'; combined_dir.mkdir(exist_ok=True)
    combined.to_csv(combined_dir / 'metrics_dev.csv', index=False)
    old_summary = pd.read_csv(ROOT / 'baseline/summary_dev.csv', dtype={'jpeg': str})
    all_summary = pd.concat([old_summary, summary], ignore_index=True)
    all_summary.to_csv(combined_dir / 'summary_dev.csv', index=False)
    additions = pd.concat([evaluate.compare_methods(combined, base, 'resshift', 42) for base in ['bicubic', 'realesrnet', 'realesrgan']], ignore_index=True)
    additions.to_csv(RUN / 'paired_resshift_dev.csv', index=False)
    old_paired = pd.read_csv(ROOT / 'baseline/paired_dev.csv', dtype={'jpeg': str})
    pd.concat([old_paired, additions], ignore_index=True).to_csv(combined_dir / 'paired_dev.csv', index=False)
    # Verify that merging added no changed baseline numeric values.
    keys = ['image_id', 'method', 'jpeg']
    pd.testing.assert_frame_equal(baseline.set_index(keys).sort_index(), combined[combined.method != 'resshift'].set_index(keys).sort_index())
    make_figures.FIGURES_DIR = RUN / 'figures'; make_figures.FIGURES_DIR.mkdir(exist_ok=True)
    make_figures.plot_jpeg_sweep(all_summary, 'dev')
    evaluation_report = {
        'split': 'dev', 'images': 64, 'resshift_rows': 256, 'combined_rows': 1024,
        'psnr_ssim': 'BT.601 Y; 4-pixel border crop', 'lpips': 'AlexNet',
        'confidence_interval': 'Existing project bootstrap half-width convention retained; 10000 resamples, seed 42. Previously identified symmetry limitation is not changed here.',
        'baseline_metrics': 'Copied from main commit; baseline SR models and their metrics are not rerun.',
        'seed_experiment': 'Not included: this is one deterministic per-image seed, not a multiple-seed study.'
    }
    (RUN / 'evaluation_report_resshift_dev.json').write_text(json.dumps(evaluation_report, indent=2))
    environment = {'python': sys.version, 'platform': platform.platform(), 'torch': torch.__version__, 'cuda': torch.version.cuda, 'gpu': torch.cuda.get_device_name(0)}
    (RUN / 'environment.json').write_text(json.dumps(environment, indent=2))
    (RUN / 'pip_freeze.txt').write_text(subprocess.check_output([sys.executable, '-m', 'pip', 'freeze'], text=True))
    (RUN / 'nvidia_smi.txt').write_text(subprocess.check_output(['nvidia-smi'], text=True))
    verify()
    (RUN / 'complete.json').write_text(json.dumps({'success': True, 'immutable_files_verified': True}, indent=2))
    print(summary.round(4).to_string(index=False), flush=True)
    print('DONE: baseline values and original input hashes preserved.', flush=True)


def export():
    verify()
    if not (RUN / 'complete.json').exists():
        raise RuntimeError('The inference/evaluation step has not completed; no final archive will be exported.')
    output = ROOT.parent / 'resshift_dev_results.zip'
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for p in sorted(RUN.rglob('*')):
            if p.is_file(): archive.write(p, 'resshift_dev_results/' + str(p.relative_to(RUN)))
        for folder in ['baseline', 'code']:
            for p in sorted((ROOT / folder).rglob('*')):
                if p.is_file() and '__pycache__' not in p.parts:
                    archive.write(p, 'resshift_dev_results/provenance/' + str(p.relative_to(ROOT)))
        for name in ['bundle_manifest.json', 'colab_runner.py', 'data/processed/manifest.csv']:
            archive.write(ROOT / name, 'resshift_dev_results/provenance/' + name)
    print(output, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['verify', 'setup', 'run', 'export'])
    action = parser.parse_args().action
    {'verify': verify, 'setup': setup, 'run': run, 'export': export}[action]()
