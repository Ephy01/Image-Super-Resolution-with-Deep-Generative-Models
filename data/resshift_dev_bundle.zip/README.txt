ResShift only, original dev inputs.
Open ResShift_only_dev.ipynb in Google Colab with a GPU runtime.
Upload resshift_dev_bundle.zip when prompted.
64 HR images, 256 LR images. Test image files are intentionally absent.
The full original manifest is retained; the runner always selects dev.
Baseline metrics are copied unchanged from main commit 896fe8c07d67164c9dedf3a513e934b257bb6216.
Never run prepare_data.py, run_pipeline.sh or upscale.py without --methods resshift.
The notebook runs only colab_runner.py: verify, setup, run, export.
A multiple-seed experiment is a separate step and is not performed by this notebook.
